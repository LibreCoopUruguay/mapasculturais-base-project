<?php
/**
 * Plugin Name: Mapas Culturais Foro SSO
 * Plugin URI: https://github.com/LibreCoopUruguay
 * Description: Sistema de Single Sign-On (SSO) que conecta WordPress con Mapas Culturais, permitiendo el acceso exclusivamente a usuarios con el Sello "Puntos de Cultura" (PDC).
 * Version: 1.0.0
 * Author: LibreCoop
 * License: GPL-2.0+
 */

// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MapasCulturais_SSO {

    // ==== CONFIGURACIÓN ====
    // Ajustar estos valores según el entorno de Mapas Culturais
    private $mapas_url = 'https://culturaenlinea.uy';
    private $shared_secret = 'CHANGE_ME_IN_CONFIG'; // Debe coincidir con $app->config['wp_sso.secret'] en Mapas
    private $required_seal_id = 5; // Reemplazar por el ID real del sello PDC en Mapas Culturais

    public function __construct() {
        // Redirigir la página de login de WP a Mapas Culturais
        add_action('login_init', array($this, 'redirect_to_mapas_login'));
        
        // Interceptar el retorno desde Mapas Culturais
        add_action('init', array($this, 'handle_mapas_callback'));
    }

    /**
     * Paso 1: Usuario intenta entrar a wp-login.php, lo mandamos a Mapas Culturais
     */
    public function redirect_to_mapas_login() {
        // Protegemos para no crear bucles si ya viene de retorno
        if (isset($_GET['mc_token']) || isset($_GET['sso_error'])) {
            return;
        }

        // Si intentan cerrar sesión, dejar que WP lo haga
        if (isset($_GET['action']) && $_GET['action'] == 'logout') {
            return;
        }

        // A dónde debe volver el usuario después del login
        $redirect_to = isset($_GET['redirect_to']) ? $_GET['redirect_to'] : home_url();

        // Parámetro de seguridad State (CSRF Protection)
        $state = wp_generate_password(24, false);
        set_transient('mapas_sso_state_' . $state, 'valid', 5 * MINUTE_IN_SECONDS);

        // Armar URL del IdP (Mapas)
        $auth_url = $this->mapas_url . '/wp-sso/login' . 
                    '?redirect_to=' . urlencode(wp_login_url()) . 
                    '&state=' . urlencode($state);

        wp_redirect($auth_url);
        exit;
    }

    /**
     * Paso 2 y 3: Mapas devolvió al usuario con un Token. Hay que verificarlo en Backend.
     */
    public function handle_mapas_callback() {
        if (!isset($_GET['mc_token']) || !isset($_GET['state'])) {
            return;
        }

        $token = sanitize_text_field($_GET['mc_token']);
        $state = sanitize_text_field($_GET['state']);

        // 1. Verificar State (CSRF)
        if (get_transient('mapas_sso_state_' . $state) !== 'valid') {
            wp_die('Error de Seguridad: Sesión de inicio de sesión caducada o inválida.', 'SSO Error', array('response' => 403));
        }
        delete_transient('mapas_sso_state_' . $state);

        // 2. Consulta Server-to-Server a Mapas Culturais
        $verify_endpoint = $this->mapas_url . '/wp-sso/verify';
        $response = wp_remote_post($verify_endpoint, array(
            'body' => array(
                'token' => $token,
                'secret' => $this->shared_secret
            ),
            'timeout' => 15
        ));

        if (is_wp_error($response)) {
            wp_die('Error conectando con Cultura en Línea: ' . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!$data || (isset($data['error']) && $data['error'] == true)) {
            wp_die('Acceso Denegado por Mapas Culturais. Mensaje: ' . ($data['message'] ?? 'Desconocido'));
        }

        // 3. LA REGLA DEL SELLO (El "Filtro")
        $tiene_sello = false;
        
        if (isset($data['agent']['seals']) && is_array($data['agent']['seals'])) {
            if (in_array($this->required_seal_id, $data['agent']['seals'])) {
                $tiene_sello = true;
            }
        }

        if (!$tiene_sello) {
            wp_die(
                '<h1>Acceso Restringido</h1><p>Lo sentimos, el acceso a este foro es exclusivo para integrantes de la red <b>Puntos de Cultura</b>.</p><p><a href="' . home_url() . '">Volver al inicio</a></p>', 
                'Acceso Denegado', 
                array('response' => 403)
            );
        }

        // 4. Iniciar Sesión en WordPress
        $this->login_or_create_wp_user($data);
    }

    /**
     * Paso 4: Mapear el usuario de Mapas a WordPress y forzar el logueo
     */
    private function login_or_create_wp_user($mapas_data) {
        $email = sanitize_email($mapas_data['user']['email']);
        $username = 'mc_' . intval($mapas_data['user']['id']);
        
        $user = get_user_by('email', $email);

        if (!$user) {
            // Si el usuario no existe en WP, lo creamos
            $random_password = wp_generate_password(12, false);
            $user_id = wp_create_user($username, $random_password, $email);
            
            if (is_wp_error($user_id)) {
                wp_die('Error creando cuenta local en el foro.');
            }

            // Actualizar nombre visible
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => sanitize_text_field($mapas_data['agent']['name'])
            ));

            $user = get_user_by('id', $user_id);
        }

        // Forzar Autenticación
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);

        // ¡Logueado! Redirigir al Foro
        wp_redirect(home_url('/'));
        exit;
    }
}

// Iniciar Plugin
new MapasCulturais_SSO();
